package com.minimarket.config;

import com.minimarket.entity.Rol;
import com.minimarket.entity.Usuario;
import com.minimarket.repository.RolRepository;
import com.minimarket.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class DataInitializer implements CommandLineRunner {

    private final RolRepository rolRepository;
    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(RolRepository rolRepository, UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.rolRepository = rolRepository;
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        Rol cliente = obtenerOCrearRol("ROLE_CLIENTE");
        Rol empleado = obtenerOCrearRol("ROLE_EMPLEADO");
        Rol administrador = obtenerOCrearRol("ROLE_ADMINISTRADOR");

        crearUsuarioSiNoExiste("cliente", "cliente123", Set.of(cliente));
        crearUsuarioSiNoExiste("empleado", "empleado123", Set.of(empleado));
        crearUsuarioSiNoExiste("admin", "admin123", Set.of(administrador));
    }

    private Rol obtenerOCrearRol(String nombre) {
        return rolRepository.findByNombre(nombre).orElseGet(() -> {
            Rol rol = new Rol();
            rol.setNombre(nombre);
            return rolRepository.save(rol);
        });
    }

    private void crearUsuarioSiNoExiste(String username, String password, Set<Rol> roles) {
        if (usuarioRepository.findByUsername(username).isEmpty()) {
            Usuario usuario = new Usuario();
            usuario.setUsername(username);
            usuario.setPassword(passwordEncoder.encode(password));
            usuario.setRoles(roles);
            usuarioRepository.save(usuario);
        }
    }
}
