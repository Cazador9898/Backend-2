package com.minimarket.security.model;

/**
 * Clase mantenida por compatibilidad. Para autenticación JWT usar
 * com.minimarket.security.dto.LoginRequest.
 */
public class LoginRequest {
}
