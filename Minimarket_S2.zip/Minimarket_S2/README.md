# Minimarket_S2 - Semana 2 Desarrollo Backend II

Proyecto actualizado para evidenciar la pauta de evaluación formativa de la Semana 2: autenticación y autorización con Spring Security y JWT.

## Requisitos cubiertos

1. Entorno configurado con dependencias de Spring Security y JWT en `pom.xml`.
2. Seguridad personalizada en `SecurityConfig`, sin login por defecto, sin HTTP Basic y con sesión `STATELESS`.
3. Entidad `Usuario` con contraseña almacenada mediante hashing BCrypt.
4. Clase `JwtUtil` para generar y validar tokens JWT con claims de roles y firma HS256.
5. Filtro `JwtAuthenticationFilter` que valida el token antes de la autenticación estándar de Spring Security.
6. Roles y permisos configurados para `CLIENTE`, `EMPLEADO` y `GERENTE`.
7. Endpoints listos para obtener evidencias en Postman.

## Ejecutar el proyecto

```bash
mvn clean spring-boot:run
```

También se puede ejecutar con el wrapper:

```bash
./mvnw spring-boot:run
```

En Windows:

```bash
mvnw.cmd spring-boot:run
```

## Usuarios iniciales

El proyecto crea automáticamente estos usuarios al iniciar:

| Usuario | Contraseña | Rol |
|---|---|---|
| cliente | 123456 | ROLE_CLIENTE |
| empleado | 123456 | ROLE_EMPLEADO |
| gerente | 123456 | ROLE_GERENTE |

## Obtener tokens JWT

### Opción 1: login normal

Endpoint:

```http
POST http://localhost:8080/auth/login
```

Body JSON para cliente:

```json
{
  "username": "cliente",
  "password": "123456"
}
```

Body JSON para empleado:

```json
{
  "username": "empleado",
  "password": "123456"
}
```

Body JSON para gerente:

```json
{
  "username": "gerente",
  "password": "123456"
}
```

La respuesta entrega un token JWT. En Postman se debe usar así:

```text
Authorization: Bearer TOKEN_GENERADO
```

### Opción 2: tokens de evidencia

Para facilitar la captura de evidencias, se agregó este endpoint educativo:

```http
GET http://localhost:8080/auth/tokens-demo
```

Este endpoint devuelve los tokens de `cliente`, `empleado` y `gerente` para probar permisos rápidamente.

## Permisos por rol

| Endpoint | CLIENTE | EMPLEADO | GERENTE |
|---|---:|---:|---:|
| GET `/api/permisos/cliente` | Permitido | Permitido | Permitido |
| GET `/api/permisos/empleado` | Denegado | Permitido | Permitido |
| GET `/api/permisos/gerente` | Denegado | Denegado | Permitido |
| `/api/productos/**` | Permitido | Permitido | Permitido |
| `/api/carrito/**` | Permitido | Permitido | Permitido |
| `/api/ventas/**` | Permitido | Permitido | Permitido |
| `/api/inventario/**` | Denegado | Permitido | Permitido |
| `/api/categorias/**` | Denegado | Permitido | Permitido |
| `/api/usuarios/**` | Denegado | Denegado | Permitido |

## Endpoints recomendados para sacar evidencias

1. Ejecutar `GET /auth/tokens-demo` y mostrar los 3 tokens.
2. Probar `GET /api/permisos/cliente` con token de cliente: debe permitir acceso.
3. Probar `GET /api/permisos/empleado` con token de cliente: debe denegar acceso.
4. Probar `GET /api/permisos/empleado` con token de empleado: debe permitir acceso.
5. Probar `GET /api/permisos/gerente` con token de empleado: debe denegar acceso.
6. Probar `GET /api/permisos/gerente` con token de gerente: debe permitir acceso.
7. Probar un endpoint protegido sin token: debe responder 401 o 403.

## Ejemplos con curl

```bash
curl -X GET http://localhost:8080/auth/tokens-demo
```

```bash
curl -X GET http://localhost:8080/api/permisos/cliente \
-H "Authorization: Bearer TOKEN_CLIENTE"
```

```bash
curl -X GET http://localhost:8080/api/permisos/empleado \
-H "Authorization: Bearer TOKEN_CLIENTE"
```

```bash
curl -X GET http://localhost:8080/api/permisos/gerente \
-H "Authorization: Bearer TOKEN_GERENTE"
```
