package com.minimarket.security.config;

import com.minimarket.entity.Rol;
import com.minimarket.entity.Usuario;
import com.minimarket.repository.RolRepository;
import com.minimarket.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Set;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initDatabase(UsuarioRepository usuarioRepository,
                                   RolRepository rolRepository,
                                   PasswordEncoder passwordEncoder) {
        return args -> {
            Rol gerenteRole = crearRolSiNoExiste(rolRepository, "ROLE_GERENTE");
            Rol empleadoRole = crearRolSiNoExiste(rolRepository, "ROLE_EMPLEADO");
            Rol clienteRole = crearRolSiNoExiste(rolRepository, "ROLE_CLIENTE");

            crearUsuarioSiNoExiste(usuarioRepository, passwordEncoder, "gerente", "123456", gerenteRole);
            crearUsuarioSiNoExiste(usuarioRepository, passwordEncoder, "empleado", "123456", empleadoRole);
            crearUsuarioSiNoExiste(usuarioRepository, passwordEncoder, "cliente", "123456", clienteRole);
        };
    }

    private Rol crearRolSiNoExiste(RolRepository rolRepository, String nombre) {
        return rolRepository.findByNombre(nombre)
                .orElseGet(() -> {
                    Rol rol = new Rol();
                    rol.setNombre(nombre);
                    return rolRepository.save(rol);
                });
    }

    private void crearUsuarioSiNoExiste(UsuarioRepository usuarioRepository,
                                        PasswordEncoder passwordEncoder,
                                        String username,
                                        String password,
                                        Rol rol) {
        if (usuarioRepository.findByUsername(username).isEmpty()) {
            Usuario usuario = new Usuario();
            usuario.setUsername(username);
            usuario.setPassword(passwordEncoder.encode(password));
            usuario.setRoles(Set.of(rol));
            usuarioRepository.save(usuario);
        }
    }
}
