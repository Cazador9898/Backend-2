package com.minimarket.security.controller;

import com.minimarket.entity.Rol;
import com.minimarket.entity.Usuario;
import com.minimarket.repository.RolRepository;
import com.minimarket.repository.UsuarioRepository;
import com.minimarket.security.model.AuthResponse;
import com.minimarket.security.model.CustomUserDetails;
import com.minimarket.security.model.LoginRequest;
import com.minimarket.security.model.RegisterRequest;
import com.minimarket.security.service.CustomUserDetailsService;
import com.minimarket.security.util.JwtUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final PasswordEncoder passwordEncoder;
    private final CustomUserDetailsService customUserDetailsService;

    public AuthController(AuthenticationManager authenticationManager,
                          JwtUtil jwtUtil,
                          UsuarioRepository usuarioRepository,
                          RolRepository rolRepository,
                          PasswordEncoder passwordEncoder,
                          CustomUserDetailsService customUserDetailsService) {
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
        this.usuarioRepository = usuarioRepository;
        this.rolRepository = rolRepository;
        this.passwordEncoder = passwordEncoder;
        this.customUserDetailsService = customUserDetailsService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
            );

            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            String token = jwtUtil.generateToken(userDetails);
            List<String> roles = userDetails.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .toList();

            return ResponseEntity.ok(new AuthResponse(token, userDetails.getUsername(), roles));
        } catch (BadCredentialsException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Credenciales incorrectas"));
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest request) {
        if (usuarioRepository.findByUsername(request.getUsername()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("error", "El usuario ya existe"));
        }

        String nombreRol = normalizarRol(request.getRol());
        Rol rol = rolRepository.findByNombre(nombreRol)
                .orElseGet(() -> {
                    Rol nuevoRol = new Rol();
                    nuevoRol.setNombre(nombreRol);
                    return rolRepository.save(nuevoRol);
                });

        Usuario usuario = new Usuario();
        usuario.setUsername(request.getUsername());
        usuario.setPassword(passwordEncoder.encode(request.getPassword()));
        usuario.setRoles(Set.of(rol));
        usuarioRepository.save(usuario);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(Map.of("mensaje", "Usuario registrado correctamente", "rol", nombreRol));
    }

    /**
     * Endpoint educativo para evidencias de la pauta.
     * Genera un JWT para cada usuario inicial: cliente, empleado y gerente.
     */
    @GetMapping("/tokens-demo")
    public ResponseEntity<?> generarTokensDemo() {
        Map<String, Object> respuesta = new LinkedHashMap<>();
        respuesta.put("descripcion", "Tokens JWT de prueba para evidenciar autenticacion y autorizacion por roles");
        respuesta.put("clave", "Usar cada token en Postman con Authorization: Bearer <token>");
        respuesta.put("cliente", crearTokenDemo("cliente", "ROLE_CLIENTE", "/api/permisos/cliente"));
        respuesta.put("empleado", crearTokenDemo("empleado", "ROLE_EMPLEADO", "/api/permisos/empleado"));
        respuesta.put("gerente", crearTokenDemo("gerente", "ROLE_GERENTE", "/api/permisos/gerente"));
        return ResponseEntity.ok(respuesta);
    }

    private Map<String, Object> crearTokenDemo(String username, String rol, String endpointPermitido) {
        UserDetails userDetails = customUserDetailsService.loadUserByUsername(username);
        return Map.of(
                "username", username,
                "password", "123456",
                "rol", rol,
                "token", jwtUtil.generateToken(userDetails),
                "endpointPermitido", endpointPermitido
        );
    }

    private String normalizarRol(String rol) {
        if (rol == null || rol.isBlank()) {
            return "ROLE_CLIENTE";
        }
        String limpio = rol.trim().toUpperCase();
        if (!limpio.startsWith("ROLE_")) {
            limpio = "ROLE_" + limpio;
        }
        return limpio;
    }
}
