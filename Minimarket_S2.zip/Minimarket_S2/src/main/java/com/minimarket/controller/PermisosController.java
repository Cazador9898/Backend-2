package com.minimarket.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/permisos")
public class PermisosController {

    @GetMapping("/cliente")
    @PreAuthorize("hasRole('CLIENTE') or hasRole('EMPLEADO') or hasRole('GERENTE')")
    public Map<String, String> accesoCliente() {
        return Map.of(
                "mensaje", "Acceso permitido a CLIENTE",
                "permiso", "Consultar productos y realizar compras"
        );
    }

    @GetMapping("/empleado")
    @PreAuthorize("hasRole('EMPLEADO') or hasRole('GERENTE')")
    public Map<String, String> accesoEmpleado() {
        return Map.of(
                "mensaje", "Acceso permitido a EMPLEADO",
                "permiso", "Gestionar productos, categorias e inventario"
        );
    }

    @GetMapping("/gerente")
    @PreAuthorize("hasRole('GERENTE')")
    public Map<String, String> accesoGerente() {
        return Map.of(
                "mensaje", "Acceso permitido a GERENTE",
                "permiso", "Administrar usuarios, ventas y configuracion general"
        );
    }
}
