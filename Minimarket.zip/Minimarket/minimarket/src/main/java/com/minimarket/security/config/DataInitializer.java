package com.minimarket.security.config;

import com.minimarket.entity.Rol;
import com.minimarket.entity.Usuario;
import com.minimarket.repository.RolRepository;
import com.minimarket.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Set;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initDatabase(
            UsuarioRepository usuarioRepository,
            RolRepository rolRepository,
            PasswordEncoder passwordEncoder) {

        return args -> {

            Rol adminRole = rolRepository.findByNombre("ROLE_ADMIN")
                    .orElseGet(() -> {
                        Rol rol = new Rol();
                        rol.setNombre("ROLE_ADMIN");
                        return rolRepository.save(rol);
                    });

            Rol empleadoRole = rolRepository.findByNombre("ROLE_EMPLEADO")
                    .orElseGet(() -> {
                        Rol rol = new Rol();
                        rol.setNombre("ROLE_EMPLEADO");
                        return rolRepository.save(rol);
                    });

            Rol clienteRole = rolRepository.findByNombre("ROLE_CLIENTE")
                    .orElseGet(() -> {
                        Rol rol = new Rol();
                        rol.setNombre("ROLE_CLIENTE");
                        return rolRepository.save(rol);
                    });

            if (usuarioRepository.findByUsername("admin").isEmpty()) {
                Usuario admin = new Usuario();
                admin.setUsername("admin");
                admin.setPassword(passwordEncoder.encode("admin123"));
                admin.setRoles(Set.of(adminRole));
                usuarioRepository.save(admin);
            }

            if (usuarioRepository.findByUsername("empleado").isEmpty()) {
                Usuario empleado = new Usuario();
                empleado.setUsername("empleado");
                empleado.setPassword(passwordEncoder.encode("empleado123"));
                empleado.setRoles(Set.of(empleadoRole));
                usuarioRepository.save(empleado);
            }

            if (usuarioRepository.findByUsername("cliente").isEmpty()) {
                Usuario cliente = new Usuario();
                cliente.setUsername("cliente");
                cliente.setPassword(passwordEncoder.encode("cliente123"));
                cliente.setRoles(Set.of(clienteRole));
                usuarioRepository.save(cliente);
            }
        };
    }
}
